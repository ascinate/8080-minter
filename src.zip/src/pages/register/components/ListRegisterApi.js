const ListNewdata =[

    {
      id:1,
      titel:"Gen 1 Mint",
      link:"/register",
      walletlink:"/register",
        discordl:"/register",
        aplictionno:"50",
        submitno:"1050",
    },

    {
        id:2,
        titel:"Gen 1 Mint",
        link:"/register",
        walletlink:"/register",
        discordl:"/register",
        aplictionno:"50",
        submitno:"1050",
      },


      {
        id:3,
        titel:"Gen 1 Mint",
        link:"/register",
        walletlink:"/register",
        discordl:"/register",
        aplictionno:"50",
        submitno:"1050",
      },



]

export default ListNewdata;