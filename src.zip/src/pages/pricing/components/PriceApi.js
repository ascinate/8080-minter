const PriceData =[

    {
      id:1,
      titel:"Gen 1",
      subtitel:"Configure the pricing for this list.",
      pricelable:"Price",
      walletlable:"Limit Per Wallet",
      maxlable:"Max Allocated Supply",
      namefill:"price",
      idvalid:"price",
    
      
    },

    {
        id:2,
        titel:"Gen 2",
        subtitel:"Configure the pricing for this list.",
        pricelable:"Price",
        walletlable:"Limit Per Wallet",
        maxlable:"Max Allocated Supply",
        namefill:"wall",
        idvalid:"wall",
    },

    {
        id:3,
        titel:"Gen 3",
        subtitel:"Configure the pricing for this list.",
        pricelable:"Price",
        walletlable:"Limit Per Wallet",
        maxlable:"Max Allocated Supply",
        namefill:"nwall",
        idvalid:"nwall",
    },


]

export default PriceData;