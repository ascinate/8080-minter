import React from "react";

function UploadInput(){
    return(
        <>
        </>
    )
};
export default UploadInput;