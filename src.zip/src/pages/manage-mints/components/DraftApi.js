const AllDraft =[

    {
      id:1,
      titel:"Gen 1",
      time:"31st of December, 2021",
      actionst:"COMPLETE & LAUNCH",
      progess:"50%",
      link:"/managemints",
    
      
    },

    {
        id:2,
        titel:"Gen 1",
        time:"31st of December, 2021",
        actionst:"COMPLETE & LAUNCH",
        progess:"50%",
        link:"/managemints",
    },

    {
      id:3,
      titel:"Gen 1",
      time:"31st of December, 2021",
      actionst:"COMPLETE & LAUNCH",
      progess:"50%",
      link:"/managemints",
    },

    {
        id:4,
        titel:"Gen 1",
        time:"31st of December, 2021",
        actionst:"COMPLETE & LAUNCH",
        progess:"50%",
        link:"/managemints",
    },

    {
        id:5,
        titel:"Gen 1",
        time:"31st of December, 2021",
        actionst:"COMPLETE & LAUNCH",
        progess:"50%",
        link:"/managemints",
    },


]

export default AllDraft;