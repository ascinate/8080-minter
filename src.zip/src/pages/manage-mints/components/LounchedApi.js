const Locncedata =[

    {
      id:1,
      titel:"Gen 1 Mint",
      time:"31st of December, 2021",
      link:"/managemints",
      editlink:"/managemints",
      colletion:"16000 ETH",
      balance:"6000 ETH",
      owner:"200",
      auhor:"208 Owners",
      url:"jirafammint",
      minted:" 700(87%)",
    
      
    },

    {
        id:2,
        titel:"Gen 2 Mint",
        time:"31st of December, 2021",
        link:"/managemints",
        editlink:"/managemints",
        colletion:"16000 ETH",
        balance:"6000 ETH",
        owner:"200",
        auhor:"208 Owners",
        url:"jirafammint",
        minted:" 700(87%)",
    },

    {
      id:3,
      titel:"Gen 3 Mint",
      time:"31st of December, 2021",
      link:"/managemints",
      editlink:"/managemints",
      colletion:"16000 ETH",
      balance:"6000 ETH",
      owner:"200",
      auhor:"208 Owners",
      url:"jirafammint",
      minted:" 700(87%)",
  },



]

export default Locncedata;